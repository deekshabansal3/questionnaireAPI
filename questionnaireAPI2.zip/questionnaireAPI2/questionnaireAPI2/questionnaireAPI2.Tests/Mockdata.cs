﻿using System;
using System.Collections;
using System.Collections.Generic;
using questionnaireAPI2.Entities;

namespace questionnaireAPI2.questionnaireAPI2.Tests
{
    public class Mockdata
    {
        
       
    }
}
