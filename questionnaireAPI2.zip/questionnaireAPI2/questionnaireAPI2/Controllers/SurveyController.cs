﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using questionnaireAPI2.Entities;
using questionnaireAPI2.questionnaireAPI2.Model;
using questionnaireAPI2.Repository.services;

namespace questionnaireAPI2.Controllers
{
    [Route("v1/[controller]")]
    [ApiController]
    public class SurveyController : Controller
    {
        private readonly SurveyInterface serviceInterface;

        public SurveyController(SurveyInterface service)
        {
            serviceInterface = service;
        }

        [HttpGet]
        public ArrayList Get([FromQuery] PagingModel pagingmodel)
        {
            //Return list of texts
            var source = serviceInterface.getTexts().ToArray();

            // Get's No of Rows Count   
            int count = source.Count();

            // Parameter is passed from Query string if it is null then it default Value will be pageNumber:1  
            int CurrentPage = pagingmodel.pageNumber;

            // Parameter is passed from Query string if it is null then it default Value will be pageSize:20  
            int PageSize = pagingmodel.pageSize;

            // Display TotalCount to Records to User  
            int TotalCount = count;

            // Calculating Totalpage by Dividing (No of Records / Pagesize)  
            int TotalPages = (int)Math.Ceiling(count / (double)PageSize);

            // Returns List of Customer after applying Paging
            var items = source.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();
            //var items = source.Skip((CurrentPage - 1) * PageSize).Take(PageSize).ToList();


            // if CurrentPage is greater than 1 means it has previousPage  
            var previousPage = CurrentPage > 1 ? "Yes" : "No";

            // if TotalPages is greater than CurrentPage means it has nextPage  
            var nextPage = CurrentPage < TotalPages ? "Yes" : "No";

            // Object which we are going to send in header   
            var paginationMetadata = new
            {
                totalCount = TotalCount,
                pageSize = PageSize,
                currentPage = CurrentPage,
                totalPages = TotalPages,
                previousPage,
                nextPage
            };

            // Setting Header  
            HttpContext.Response.Headers.Add("Paging-Headers", JsonConvert.SerializeObject(paginationMetadata));
            ArrayList mylist = new ArrayList(items);
            // Returing List of Customers Collections  
            return mylist;
        }

        [HttpPost]
        public HttpStatusCode Post([FromBody] QuestionnaireRequest request)
        {
            serviceInterface.postItems(request);
            return HttpStatusCode.NoContent;
        }

        [Route("departmentResults")]
        [HttpPost]
        public QuestionnaireItemRespnse departmentResults ()
        {
            return serviceInterface.departmentResults();
        }
       
    }
}
